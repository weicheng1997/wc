- audio 标签 //音频标签
autoplay 自动播放
loop 无限循环
controls 添加控制面板

- animation 标签
steps(n)将两个关键帧切换分成n段，每一段都是运动是瞬间结束的，在每一段(每一帧)结束后会停留 两关键帧之间的时间差/n 的时间。
steps(n) 适用于线式偏移。